const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../')));

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/homecare', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Patient Schema
const patientSchema = new mongoose.Schema({
    name: { type: String, required: true },
    age: { type: Number, required: true },
    condition: { type: String, required: true },
    address: { type: String, required: true },
    phone: { type: String, required: true },
    emergencyContact: { type: String, required: true },
    status: { type: String, default: 'active' },
    assignedStaff: { type: String },
    createdAt: { type: Date, default: Date.now },
    lastVisit: { type: Date, default: Date.now },
    medicalHistory: [{ 
        date: Date, 
        notes: String, 
        provider: String 
    }],
    medications: [{ 
        name: String, 
        dosage: String, 
        frequency: String 
    }]
});

// Staff Schema
const staffSchema = new mongoose.Schema({
    name: { type: String, required: true },
    role: { type: String, required: true },
    license: { type: String, required: true },
    phone: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    status: { type: String, default: 'available' },
    patients: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Patient' }],
    createdAt: { type: Date, default: Date.now },
    schedule: [{
        date: Date,
        startTime: String,
        endTime: String,
        availability: Boolean
    }]
});

// Appointment Schema
const appointmentSchema = new mongoose.Schema({
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient', required: true },
    staff: { type: mongoose.Schema.Types.ObjectId, ref: 'Staff', required: true },
    date: { type: Date, required: true },
    time: { type: String, required: true },
    type: { type: String, required: true },
    status: { type: String, default: 'scheduled' },
    notes: { type: String },
    createdAt: { type: Date, default: Date.now },
    completedAt: { type: Date },
    duration: { type: Number, default: 60 }, // minutes
    location: { type: String, default: 'Patient Home' }
});

// Models
const Patient = mongoose.model('Patient', patientSchema);
const Staff = mongoose.model('Staff', staffSchema);
const Appointment = mongoose.model('Appointment', appointmentSchema);

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.sendStatus(401);
    }

    jwt.verify(token, 'your-secret-key', (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Routes

// Serve main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../index.html'));
});

// Authentication Routes
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const staff = await Staff.findOne({ email });

        if (!staff || !await bcrypt.compare(password, staff.password)) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { id: staff._id, email: staff.email, role: staff.role },
            'your-secret-key',
            { expiresIn: '24h' }
        );

        res.json({
            token,
            user: {
                id: staff._id,
                name: staff.name,
                email: staff.email,
                role: staff.role
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, role, license, phone, email, password } = req.body;
        
        const existingStaff = await Staff.findOne({ email });
        if (existingStaff) {
            return res.status(400).json({ message: 'Staff member already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const staff = new Staff({
            name,
            role,
            license,
            phone,
            email,
            password: hashedPassword
        });

        await staff.save();
        res.status(201).json({ message: 'Staff member registered successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Patient Routes
app.get('/api/patients', async (req, res) => {
    try {
        const patients = await Patient.find().sort({ createdAt: -1 });
        res.json(patients);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.post('/api/patients', async (req, res) => {
    try {
        const patient = new Patient(req.body);
        await patient.save();
        res.status(201).json(patient);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.get('/api/patients/:id', async (req, res) => {
    try {
        const patient = await Patient.findById(req.params.id);
        if (!patient) {
            return res.status(404).json({ message: 'Patient not found' });
        }
        res.json(patient);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.put('/api/patients/:id', async (req, res) => {
    try {
        const patient = await Patient.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!patient) {
            return res.status(404).json({ message: 'Patient not found' });
        }
        res.json(patient);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Staff Routes
app.get('/api/staff', async (req, res) => {
    try {
        const staff = await Staff.find().select('-password').populate('patients');
        res.json(staff);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.post('/api/staff', async (req, res) => {
    try {
        const { password, ...staffData } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const staff = new Staff({
            ...staffData,
            password: hashedPassword
        });
        
        await staff.save();
        const staffResponse = staff.toObject();
        delete staffResponse.password;
        
        res.status(201).json(staffResponse);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Appointment Routes
app.get('/api/appointments', async (req, res) => {
    try {
        const appointments = await Appointment.find()
            .populate('patient', 'name condition')
            .populate('staff', 'name role')
            .sort({ date: 1, time: 1 });
        res.json(appointments);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.post('/api/appointments', async (req, res) => {
    try {
        const appointment = new Appointment(req.body);
        await appointment.save();
        
        const populatedAppointment = await Appointment.findById(appointment._id)
            .populate('patient', 'name condition')
            .populate('staff', 'name role');
            
        res.status(201).json(populatedAppointment);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.put('/api/appointments/:id', async (req, res) => {
    try {
        const appointment = await Appointment.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        ).populate('patient', 'name condition')
         .populate('staff', 'name role');
         
        if (!appointment) {
            return res.status(404).json({ message: 'Appointment not found' });
        }
        res.json(appointment);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Analytics Routes
app.get('/api/analytics/dashboard', async (req, res) => {
    try {
        const totalPatients = await Patient.countDocuments();
        const activePatients = await Patient.countDocuments({ status: 'active' });
        const totalStaff = await Staff.countDocuments();
        const onDutyStaff = await Staff.countDocuments({ status: 'on-duty' });
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const todayAppointments = await Appointment.countDocuments({
            date: { $gte: today, $lt: tomorrow }
        });
        
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay());
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 7);
        
        const weekAppointments = await Appointment.countDocuments({
            date: { $gte: weekStart, $lt: weekEnd }
        });
        
        const pendingAppointments = await Appointment.countDocuments({ status: 'pending' });
        
        // Calculate new patients this week
        const newPatients = await Patient.countDocuments({
            createdAt: { $gte: weekStart, $lt: weekEnd }
        });

        res.json({
            patients: {
                total: totalPatients,
                active: activePatients,
                newThisWeek: newPatients
            },
            staff: {
                total: totalStaff,
                onDuty: onDutyStaff,
                available: totalStaff - onDutyStaff
            },
            appointments: {
                today: todayAppointments,
                thisWeek: weekAppointments,
                pending: pendingAppointments
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Reports Routes
app.get('/api/reports/patient-care', async (req, res) => {
    try {
        const totalPatients = await Patient.countDocuments();
        const activePatients = await Patient.countDocuments({ status: 'active' });
        const completedAppointments = await Appointment.countDocuments({ status: 'completed' });
        const totalAppointments = await Appointment.countDocuments();
        
        const completionRate = totalAppointments > 0 ? 
            Math.round((completedAppointments / totalAppointments) * 100) : 0;

        res.json({
            title: 'Patient Care Report',
            totalPatients,
            activePatients,
            completedCases: completedAppointments,
            completionRate: `${completionRate}%`,
            satisfactionRate: '94%' // This would come from patient feedback in a real system
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

app.get('/api/reports/staff-performance', async (req, res) => {
    try {
        const totalStaff = await Staff.countDocuments();
        const onDutyStaff = await Staff.countDocuments({ status: 'on-duty' });
        const totalPatients = await Patient.countDocuments();
        
        const averagePatientLoad = totalStaff > 0 ? 
            Math.round(totalPatients / totalStaff) : 0;

        res.json({
            title: 'Staff Performance Report',
            totalStaff,
            onDutyStaff,
            averagePatientLoad,
            efficiency: '87%',
            responseTime: '15 minutes'
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error(error);
    res.status(500).json({ message: 'Something went wrong!' });
});

// Start server
app.listen(PORT, () => {
    console.log(`🏥 Home Care Link Server running on port ${PORT}`);
    console.log(`📊 Dashboard available at http://localhost:${PORT}`);
    console.log(`🔗 API endpoints available at http://localhost:${PORT}/api`);
});

module.exports = app;