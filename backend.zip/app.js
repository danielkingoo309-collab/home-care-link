// Home Care Link - Regional Hospital Home Health Management System
// JavaScript Application Logic

class HomeCareSystem {
    constructor() {
        this.patients = [
            {
                id: 1,
                name: "John Smith",
                age: 65,
                condition: "Post-Surgery Recovery",
                status: "active",
                address: "123 Main St, Central City",
                phone: "(555) 123-4567",
                emergencyContact: "Jane Smith - (555) 123-4568",
                assignedStaff: "Dr. Sarah Wilson",
                lastVisit: "2024-01-15"
            },
            {
                id: 2,
                name: "Mary Johnson",
                age: 72,
                condition: "Physical Therapy",
                status: "pending",
                address: "456 Oak Ave, Central City",
                phone: "(555) 234-5678",
                emergencyContact: "Tom Johnson - (555) 234-5679",
                assignedStaff: "Mike Thompson",
                lastVisit: "2024-01-14"
            },
            {
                id: 3,
                name: "Robert Davis",
                age: 58,
                condition: "Homebound Care",
                status: "active",
                address: "789 Pine Rd, Central City",
                phone: "(555) 345-6789",
                emergencyContact: "Susan Davis - (555) 345-6790",
                assignedStaff: "Dr. Sarah Wilson",
                lastVisit: "2024-01-16"
            }
        ];

        this.staff = [
            {
                id: 1,
                name: "Dr. Sarah Wilson",
                role: "Registered Nurse",
                license: "RN-12345",
                phone: "(555) 111-2222",
                email: "s.wilson@hospital.com",
                status: "on-duty",
                patients: ["John Smith", "Robert Davis"]
            },
            {
                id: 2,
                name: "Mike Thompson",
                role: "Physical Therapist",
                license: "PT-67890",
                phone: "(555) 333-4444",
                email: "m.thompson@hospital.com",
                status: "on-duty",
                patients: ["Mary Johnson"]
            },
            {
                id: 3,
                name: "Lisa Brown",
                role: "Home Health Aide",
                license: "HHA-11111",
                phone: "(555) 555-6666",
                email: "l.brown@hospital.com",
                status: "available",
                patients: []
            }
        ];

        this.appointments = [
            {
                id: 1,
                patientName: "John Smith",
                staffName: "Dr. Sarah Wilson",
                date: "2024-01-17",
                time: "10:00",
                type: "Wound Care",
                status: "scheduled",
                notes: "Post-surgical wound check and dressing change"
            },
            {
                id: 2,
                patientName: "Mary Johnson",
                staffName: "Mike Thompson",
                date: "2024-01-17",
                time: "14:00",
                type: "Physical Therapy",
                status: "pending",
                notes: "Mobility assessment and exercise routine"
            },
            {
                id: 3,
                patientName: "Robert Davis",
                staffName: "Dr. Sarah Wilson",
                date: "2024-01-17",
                time: "16:30",
                type: "Medication Review",
                status: "scheduled",
                notes: "Review current medications and dosages"
            }
        ];

        this.init();
    }

    init() {
        this.updateDashboardStats();
        this.setupEventListeners();
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 60000); // Update every minute
    }

    updateDashboardStats() {
        // Update patient stats
        document.getElementById('totalPatients').textContent = this.patients.length;
        document.getElementById('activePatients').textContent = 
            this.patients.filter(p => p.status === 'active').length;
        document.getElementById('newPatients').textContent = 
            this.patients.filter(p => this.isNewThisWeek(p.lastVisit)).length;

        // Update staff stats
        document.getElementById('totalStaff').textContent = this.staff.length;
        document.getElementById('onDutyStaff').textContent = 
            this.staff.filter(s => s.status === 'on-duty').length;
        document.getElementById('availableStaff').textContent = 
            this.staff.filter(s => s.status === 'available').length;

        // Update appointment stats
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('todayAppointments').textContent = 
            this.appointments.filter(a => a.date === today).length;
        document.getElementById('weekAppointments').textContent = 
            this.appointments.filter(a => this.isThisWeek(a.date)).length;
        document.getElementById('pendingAppointments').textContent = 
            this.appointments.filter(a => a.status === 'pending').length;
    }

    isNewThisWeek(dateString) {
        const date = new Date(dateString);
        const today = new Date();
        const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
        return date >= weekAgo && date <= today;
    }

    isThisWeek(dateString) {
        const date = new Date(dateString);
        const today = new Date();
        const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
        const endOfWeek = new Date(today.setDate(today.getDate() - today.getDay() + 6));
        return date >= startOfWeek && date <= endOfWeek;
    }

    updateDateTime() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        
        // You can add a date/time display element if needed
        console.log('System updated:', now.toLocaleDateString('en-US', options));
    }

    setupEventListeners() {
        // Patient form submission
        document.getElementById('patientForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addPatient();
        });

        // Staff form submission
        document.getElementById('staffForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addStaff();
        });

        // Schedule form submission
        document.getElementById('scheduleForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.scheduleAppointment();
        });

        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
    }

    addPatient() {
        const formData = {
            id: this.patients.length + 1,
            name: document.getElementById('patientName').value,
            age: parseInt(document.getElementById('patientAge').value),
            condition: document.getElementById('patientCondition').value,
            address: document.getElementById('patientAddress').value,
            phone: document.getElementById('patientPhone').value,
            emergencyContact: document.getElementById('emergencyContact').value,
            status: 'active',
            lastVisit: new Date().toISOString().split('T')[0]
        };

        this.patients.push(formData);
        this.updatePatientList();
        this.updateDashboardStats();
        this.closeModal('patientModal');
        this.showNotification('Patient added successfully!', 'success');
        document.getElementById('patientForm').reset();
    }

    addStaff() {
        const formData = {
            id: this.staff.length + 1,
            name: document.getElementById('staffName').value,
            role: document.getElementById('staffRole').value,
            license: document.getElementById('staffLicense').value,
            phone: document.getElementById('staffPhone').value,
            email: document.getElementById('staffEmail').value,
            status: 'available',
            patients: []
        };

        this.staff.push(formData);
        this.updateStaffList();
        this.updateDashboardStats();
        this.closeModal('staffModal');
        this.showNotification('Staff member added successfully!', 'success');
        document.getElementById('staffForm').reset();
    }

    scheduleAppointment() {
        const formData = {
            id: this.appointments.length + 1,
            patientName: document.getElementById('appointmentPatient').value,
            staffName: document.getElementById('appointmentStaff').value,
            date: document.getElementById('appointmentDate').value,
            time: document.getElementById('appointmentTime').value,
            type: document.getElementById('appointmentType').value,
            notes: document.getElementById('appointmentNotes').value,
            status: 'scheduled'
        };

        this.appointments.push(formData);
        this.updateScheduleList();
        this.updateDashboardStats();
        this.closeModal('scheduleModal');
        this.showNotification('Appointment scheduled successfully!', 'success');
        document.getElementById('scheduleForm').reset();
    }

    updatePatientList() {
        const patientList = document.getElementById('patientList');
        patientList.innerHTML = '';

        this.patients.slice(-3).forEach(patient => {
            const patientItem = document.createElement('div');
            patientItem.className = 'patient-item';
            patientItem.innerHTML = `
                <div>
                    <strong>${patient.name}</strong><br>
                    <small>${patient.condition}</small>
                </div>
                <span class="status ${patient.status}">${patient.status.charAt(0).toUpperCase() + patient.status.slice(1)}</span>
            `;
            patientList.appendChild(patientItem);
        });
    }

    updateStaffList() {
        const staffList = document.getElementById('staffList');
        staffList.innerHTML = '';

        this.staff.slice(-3).forEach(staff => {
            const staffItem = document.createElement('div');
            staffItem.className = 'staff-item';
            const statusText = staff.status === 'on-duty' ? 'On Duty' : 'Available';
            staffItem.innerHTML = `
                <div>
                    <strong>${staff.name}</strong><br>
                    <small>${staff.role}</small>
                </div>
                <span class="status ${staff.status === 'on-duty' ? 'active' : 'pending'}">${statusText}</span>
            `;
            staffList.appendChild(staffItem);
        });
    }

    updateScheduleList() {
        const scheduleList = document.getElementById('scheduleList');
        scheduleList.innerHTML = '';

        this.appointments.slice(-3).forEach(appointment => {
            const scheduleItem = document.createElement('div');
            scheduleItem.className = 'patient-item';
            scheduleItem.innerHTML = `
                <div>
                    <strong>${appointment.time} - ${appointment.patientName}</strong><br>
                    <small>${appointment.type} - ${appointment.staffName}</small>
                </div>
                <span class="status ${appointment.status === 'scheduled' ? 'active' : 'pending'}">${appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}</span>
            `;
            scheduleList.appendChild(scheduleItem);
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            background: ${type === 'success' ? '#4CAF50' : '#2196F3'};
            color: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            z-index: 3000;
            font-weight: 600;
            animation: slideIn 0.3s ease;
        `;
        notification.textContent = message;

        // Add animation keyframes
        if (!document.getElementById('notificationStyles')) {
            const style = document.createElement('style');
            style.id = 'notificationStyles';
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                @keyframes slideOut {
                    from { transform: translateX(0); opacity: 1; }
                    to { transform: translateX(100%); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }

        document.body.appendChild(notification);

        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    generateReport(type) {
        let reportData = {};
        let reportTitle = '';

        switch(type) {
            case 'patient':
                reportData = {
                    title: 'Patient Care Report',
                    totalPatients: this.patients.length,
                    activePatients: this.patients.filter(p => p.status === 'active').length,
                    completedCases: Math.floor(this.patients.length * 0.87),
                    averageCareTime: '12 days',
                    satisfactionRate: '94%'
                };
                reportTitle = 'Patient Care Report Generated';
                break;
            case 'staff':
                reportData = {
                    title: 'Staff Performance Report',
                    totalStaff: this.staff.length,
                    onDutyStaff: this.staff.filter(s => s.status === 'on-duty').length,
                    averagePatientLoad: Math.floor(this.patients.length / this.staff.length),
                    efficiency: '87%',
                    responseTime: '15 minutes'
                };
                reportTitle = 'Staff Performance Report Generated';
                break;
            case 'financial':
                reportData = {
                    title: 'Financial Summary Report',
                    monthlyRevenue: '$245,000',
                    operatingCosts: '$180,000',
                    netProfit: '$65,000',
                    costPerPatient: '$1,929',
                    reimbursementRate: '92%'
                };
                reportTitle = 'Financial Summary Report Generated';
                break;
        }

        // Simulate report generation
        this.showNotification(`${reportTitle} - Check your downloads folder`, 'success');
        
        // In a real application, this would generate and download a PDF report
        console.log('Generated Report:', reportData);
    }

    closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
}

// Global functions for HTML onclick events
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function generateReport(type) {
    homeCareSystem.generateReport(type);
}

// Initialize the system when the page loads
let homeCareSystem;
document.addEventListener('DOMContentLoaded', function() {
    homeCareSystem = new HomeCareSystem();
    
    // Add some dynamic effects
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.style.animation = 'fadeInUp 0.6s ease forwards';
    });

    // Add fadeInUp animation
    if (!document.getElementById('cardAnimations')) {
        const style = document.createElement('style');
        style.id = 'cardAnimations';
        style.textContent = `
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            .card {
                opacity: 0;
            }
        `;
        document.head.appendChild(style);
    }
});

// Service Worker for offline functionality (Progressive Web App)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed');
            });
    });
}

// Export for potential Node.js backend integration
if (typeof module !== 'undefined' && module.exports) {
    module.exports = HomeCareSystem;
}