// Mobile-optimized version of Home Care Link
// Enhanced for Android APK with Cordova features

class MobileHomeCareSystem extends HomeCareSystem {
    constructor() {
        super();
        this.initMobileFeatures();
    }

    initMobileFeatures() {
        // Wait for Cordova to be ready
        document.addEventListener('deviceready', () => {
            console.log('📱 Cordova device ready');
            this.setupMobileUI();
            this.enableOfflineMode();
        }, false);

        // Fallback for web version
        if (!window.cordova) {
            setTimeout(() => {
                this.setupMobileUI();
                this.enableOfflineMode();
            }, 1000);
        }
    }

    setupMobileUI() {
        // Add mobile-specific styles
        const mobileStyles = document.createElement('style');
        mobileStyles.textContent = `
            @media (max-width: 768px) {
                .header { padding: 0.5rem 1rem; }
                .logo { width: 45px; height: 45px; }
                .logo i { font-size: 20px; }
                .logo-text h1 { font-size: 1.3rem; }
                .logo-text p { font-size: 0.7rem; }
                .dashboard { grid-template-columns: 1fr; gap: 1rem; }
                .card { padding: 1.5rem; }
                .stats { flex-wrap: wrap; gap: 10px; }
                .stat { min-width: 80px; }
                .btn { padding: 10px 20px; font-size: 0.9rem; }
                .modal-content { width: 95%; padding: 1.5rem; }
            }
            
            /* Touch-friendly buttons */
            .btn, .patient-item, .staff-item {
                min-height: 44px;
                touch-action: manipulation;
            }
            
            /* Prevent zoom on input focus */
            input, select, textarea {
                font-size: 16px;
            }
        `;
        document.head.appendChild(mobileStyles);

        // Add mobile navigation
        this.addMobileNavigation();
    }

    addMobileNavigation() {
        const nav = document.createElement('div');
        nav.style.cssText = `
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
            padding: 10px;
            display: flex;
            justify-content: space-around;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
            z-index: 1000;
        `;

        const navItems = [
            { icon: 'fas fa-home', label: 'Dashboard', action: () => this.scrollToTop() },
            { icon: 'fas fa-user-injured', label: 'Patients', action: () => openModal('patientModal') },
            { icon: 'fas fa-user-md', label: 'Staff', action: () => openModal('staffModal') },
            { icon: 'fas fa-calendar', label: 'Schedule', action: () => openModal('scheduleModal') }
        ];

        navItems.forEach(item => {
            const button = document.createElement('button');
            button.style.cssText = `
                background: none;
                border: none;
                color: #666;
                font-size: 12px;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 4px;
                padding: 8px;
                border-radius: 8px;
                transition: all 0.3s ease;
                min-width: 60px;
            `;
            
            button.innerHTML = `
                <i class="${item.icon}" style="font-size: 18px;"></i>
                <span>${item.label}</span>
            `;
            
            button.addEventListener('click', item.action);
            nav.appendChild(button);
        });

        document.body.appendChild(nav);
        
        // Add bottom padding to prevent content overlap
        document.body.style.paddingBottom = '80px';
    }

    scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    enableOfflineMode() {
        // Enhanced offline capabilities
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js')
                .then(registration => {
                    console.log('📱 Service Worker registered for offline mode');
                })
                .catch(error => {
                    console.log('Service Worker registration failed');
                });
        }

        // Store data locally
        this.saveToLocalStorage();
        
        // Sync when online
        window.addEventListener('online', () => {
            this.syncOfflineData();
            this.showNotification('📶 Back online - syncing data', 'success');
        });

        window.addEventListener('offline', () => {
            this.showNotification('📵 Offline mode - data saved locally', 'info');
        });
    }

    saveToLocalStorage() {
        localStorage.setItem('homeCarePatients', JSON.stringify(this.patients));
        localStorage.setItem('homeCareStaff', JSON.stringify(this.staff));
        localStorage.setItem('homeCareAppointments', JSON.stringify(this.appointments));
    }

    loadFromLocalStorage() {
        const patients = localStorage.getItem('homeCarePatients');
        const staff = localStorage.getItem('homeCareStaff');
        const appointments = localStorage.getItem('homeCareAppointments');

        if (patients) this.patients = JSON.parse(patients);
        if (staff) this.staff = JSON.parse(staff);
        if (appointments) this.appointments = JSON.parse(appointments);
    }

    syncOfflineData() {
        // Sync with server when online
        if (navigator.onLine) {
            this.saveToLocalStorage();
            console.log('📱 Data synced with local storage');
        }
    }

    // Override parent methods to include mobile optimizations
    addPatient() {
        super.addPatient();
        this.saveToLocalStorage();
        
        // Mobile haptic feedback if available
        if (navigator.vibrate) {
            navigator.vibrate(50);
        }
    }

    addStaff() {
        super.addStaff();
        this.saveToLocalStorage();
        
        if (navigator.vibrate) {
            navigator.vibrate(50);
        }
    }

    scheduleAppointment() {
        super.scheduleAppointment();
        this.saveToLocalStorage();
        
        if (navigator.vibrate) {
            navigator.vibrate(50);
        }
    }
}

// Initialize mobile version when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Check if running in Cordova or mobile browser
    const isMobile = window.cordova || /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    if (isMobile) {
        homeCareSystem = new MobileHomeCareSystem();
        console.log('📱 Mobile Home Care System initialized');
    } else {
        homeCareSystem = new HomeCareSystem();
        console.log('💻 Desktop Home Care System initialized');
    }
});

// Export for Cordova
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MobileHomeCareSystem;
}